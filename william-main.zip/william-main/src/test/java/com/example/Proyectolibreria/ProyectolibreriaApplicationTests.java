package com.example.Proyectolibreria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectolibreriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
